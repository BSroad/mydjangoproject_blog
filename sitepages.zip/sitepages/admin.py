from django.contrib import admin
from .models import Sitepages


# Register your models here.
admin.site.register(Sitepages)