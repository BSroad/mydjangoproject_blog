from django.shortcuts import render, get_object_or_404
from .models import Post
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger


def home(request, page_number=1):
    posts =  Post.objects.all().order_by('-pub_date')
    current_page = Paginator(posts, 2)
    try:
        posts_list = current_page.page(page_number)
        # username = auth.get_user(request).username
        context= {"posts": posts_list,}
    except EmptyPage:
        posts_list = current_page.page(current_page.num_pages)
        context= {"posts": posts_list,}
    except PageNotAnInteger:
        posts_list = current_page.page(1)
        context= {"posts": posts_list,}
    return render(request, 'posts/home.html', context)


def post_details(request, post_id):
    post = get_object_or_404(Post, pk=post_id)
    return render(request, 'posts/post_detail.html', {'post': post})






